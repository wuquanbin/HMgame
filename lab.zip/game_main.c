#include "game_common.h"
#include "game_mqtt.h"
#include "game_port.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "ohos_run.h"

#define GAME_TASK_STACK_SIZE       0x2000
#define DISPLAY_TASK_STACK_SIZE    0x1000
#define KEY_TASK_STACK_SIZE        0x1000
#define GAME_TASK_PRIO             (osPriority_t)(17)

#define KEY_READ_PERIOD_MS         30
#define KEY_DEBOUNCE_MS            120
#define GAME_OVER_EXIT_DELAY_MS    1000
#define MENU_SCORE_MARK            0
extern void game_display_task(void *argument);

static const uint8_t g_menu_icons[GAME_ID_COUNT][GAME_FRAME_BYTES] = {
    {
        0x00, 0x3E, 0x20, 0x20, 0x3C, 0x04, 0x04, 0x7C
    },
    {
        0x00, 0x00, 0x7E, 0x7E, 0x18, 0x18, 0x00, 0x00
    },
    {
        0x18, 0x18, 0x3C, 0x5A, 0x18, 0x24, 0x42, 0x00
    },
    {
        0x18, 0x18, 0x7E, 0x3C, 0x18, 0x24, 0x42, 0x00
    }
};

static volatile game_key_t g_last_key = GAME_KEY_NONE;
static volatile bool g_key_pending;
static volatile uint32_t g_seed_counter;

static void show_game_over_frame(void)
{
    static const uint8_t frame[GAME_FRAME_BYTES] = {
        0xFF, 0x81, 0x99, 0xA5, 0xA5, 0x99, 0x81, 0xFF
    };

    game_display_set_frame(frame);
}

static void show_menu(game_id_t selected)
{
    game_display_set_frame(g_menu_icons[selected]);
    game_display_show_score((uint16_t)(selected + 1U));
}

static void render_driver(const game_driver_t *driver)
{
    uint8_t frame[GAME_FRAME_BYTES];

    driver->render(frame);
    game_display_set_frame(frame);
    game_display_show_score(driver->score());
}

static osThreadId_t create_thread(const char *name, osThreadFunc_t func, uint32_t stack_size)
{
    osThreadAttr_t attr = {0};
    osThreadId_t thread_id;

    attr.name = name;
    attr.stack_size = stack_size;
    attr.priority = GAME_TASK_PRIO;
    thread_id = osThreadNew(func, NULL, &attr);
    if (thread_id == NULL) {
        printf("create %s failed\r\n", name);
    }
    return thread_id;
}

static game_key_t take_key(void)
{
    game_key_t key = GAME_KEY_NONE;

    if (g_key_pending) {
        key = g_last_key;
        g_key_pending = false;
    }
    return key;
}

static void clear_pending_key(void)
{
    g_last_key = GAME_KEY_NONE;
    g_key_pending = false;
}

static bool game_over_func_pressed(game_key_t *last_direct_key)
{
    uint16_t raw = game_key_read_raw();
    game_key_t key = game_key_from_raw(raw);

    if (key == GAME_KEY_NONE) {
        *last_direct_key = GAME_KEY_NONE;
        return false;
    }
    if (key == *last_direct_key) {
        return false;
    }

    *last_direct_key = key;
    printf("game over direct key: %s raw=%u\r\n", game_key_name(key), (unsigned int)raw);
    return key == GAME_KEY_FUNC;
}

static void game_key_task(void *argument)
{
    game_key_t key;
    game_key_t last_key = GAME_KEY_NONE;
    uint16_t raw;

    (void)argument;
    printf("AD key: SW1=FUNC, SW2=RIGHT, SW3=UP, SW4=LEFT, SW5=DOWN\r\n");
    printf("wire: S -> GPIO34(ADC1_CH6), V -> 3.3V, G -> GND\r\n");
    while (1) {
        raw = game_key_read_raw();
        key = game_key_from_raw(raw);
        g_seed_counter++;
        if ((key != GAME_KEY_NONE) && (key != last_key)) {
            printf("key: %s raw=%u pending=%u\r\n",
                game_key_name(key), (unsigned int)raw, g_key_pending ? 1U : 0U);
            g_last_key = key;
            g_key_pending = true;
            game_wake_controller(GAME_EVENT_KEY);
            game_delay_ms(KEY_DEBOUNCE_MS);
        }
        last_key = key;
        game_delay_ms(KEY_READ_PERIOD_MS);
    }
}

static game_id_t menu_loop(game_id_t selected)
{
    game_key_t key;
    uint32_t events;

    show_menu(selected);
    while (1) {
        events = osThreadFlagsWait(GAME_EVENT_KEY, osFlagsWaitAny, game_ms_to_ticks(300));
        if ((events & osFlagsError) != 0U) {
            continue;
        }
        key = take_key();
        if (key == GAME_KEY_FUNC) {
            return selected;
        }
        if (key == GAME_KEY_RIGHT) {
            selected = (game_id_t)((selected + 1U) % GAME_ID_COUNT);
            show_menu(selected);
        } else if (key == GAME_KEY_LEFT) {
            selected = (selected == 0U) ? (GAME_ID_COUNT - 1U) : (game_id_t)(selected - 1U);
            show_menu(selected);
        }
    }
}

static bool wait_for_revive_or_restart(game_id_t game_id, uint16_t score)
{
    const game_driver_t *driver = game_get_driver(game_id);
    game_key_t key;
    game_key_t last_direct_key;

    printf("game over wait: %s score=%u publish and wait for SW1/FUNC, app revive or app exit\r\n",
        driver->name, (unsigned int)score);
    game_mqtt_clear_commands(game_id);
    show_game_over_frame();
    game_display_show_score(score);
    last_direct_key = game_key_read();
    game_mqtt_publish_game_over(game_id, score);

    while (1) {
        if (game_over_func_pressed(&last_direct_key)) {
            printf("game over exit by direct SW1/FUNC: %s score=%u\r\n",
                driver->name, (unsigned int)score);
            game_mqtt_publish_game_exit(game_id, score);
            clear_pending_key();
            return false;
        }
        key = take_key();
        if (key == GAME_KEY_FUNC) {
            printf("game over exit by key task SW1/FUNC: %s score=%u\r\n",
                driver->name, (unsigned int)score);
            game_mqtt_publish_game_exit(game_id, score);
            clear_pending_key();
            return false;
        } else if (key != GAME_KEY_NONE) {
            printf("game over ignored key: %s waiting for SW1/FUNC or app command\r\n",
                game_key_name(key));
        }
        if (game_mqtt_take_exit(game_id)) {
            printf("game over exit by app command: %s score=%u, keep frame %u ms\r\n",
                driver->name, (unsigned int)score, (unsigned int)GAME_OVER_EXIT_DELAY_MS);
            game_delay_ms(GAME_OVER_EXIT_DELAY_MS);
            game_mqtt_publish_game_exit(game_id, score);
            clear_pending_key();
            return false;
        }
        if (game_mqtt_take_revive(game_id)) {
            printf("game over revive by app command: %s score=%u\r\n",
                driver->name, (unsigned int)score);
            clear_pending_key();
            return true;
        }
        game_delay_ms(KEY_READ_PERIOD_MS);
    }
}

static void run_selected_game(game_id_t game_id)
{
    const game_driver_t *driver = game_get_driver(game_id);
    bool alive = true;
    bool should_step;
    bool render_needed;
    uint32_t events;
    uint32_t tick_delay;
    uint32_t wait_ticks;
    uint32_t now_ticks;
    uint32_t next_tick;
    game_key_t key;

    printf("start game: %s\r\n", driver->name);
    game_seed(g_seed_counter);
    driver->init(0);
    game_buzzer_double(60);
    render_driver(driver);
    tick_delay = game_ms_to_ticks(driver->tick_ms);
    next_tick = osKernelGetTickCount() + tick_delay;

    while (1) {
        should_step = false;
        render_needed = false;
        now_ticks = osKernelGetTickCount();
        if ((int32_t)(next_tick - now_ticks) <= 0) {
            events = 0U;
            should_step = true;
        } else {
            wait_ticks = next_tick - now_ticks;
            events = osThreadFlagsWait(GAME_EVENT_MASK, osFlagsWaitAny, wait_ticks);
            if (events == osFlagsErrorTimeout) {
                should_step = true;
            } else if ((events & osFlagsError) != 0U) {
                continue;
            }
        }

        key = take_key();
        if (key != GAME_KEY_NONE) {
            if (key == GAME_KEY_FUNC && driver->id == GAME_ID_SNAKE) {
                game_buzzer_beep(35);
            } else {
                driver->handle_key(key);
            }
            render_needed = true;
        }

        if (should_step) {
            next_tick = osKernelGetTickCount() + tick_delay;
            alive = driver->step();
            render_driver(driver);
            if (!alive) {
                uint16_t score = driver->score();
                printf("game over: %s score=%u\r\n", driver->name, (unsigned int)score);
                clear_pending_key();
                game_buzzer_double(180);
                if (wait_for_revive_or_restart(game_id, score)) {
                    printf("revive: %s score=%u\r\n", driver->name, (unsigned int)score);
                    driver->revive();
                    game_buzzer_double(60);
                    render_driver(driver);
                    next_tick = osKernelGetTickCount() + tick_delay;
                    continue;
                }
                return;
            }
        } else if (render_needed) {
            render_driver(driver);
        }
    }
}

static void game_controller_task(void *argument)
{
    game_id_t selected = GAME_ID_SNAKE;

    (void)argument;
    game_set_controller_thread(osThreadGetId());
    game_mqtt_start();
    printf("ESP32 pixel game console ready\r\n");

    while (1) {
        selected = menu_loop(selected);
        run_selected_game(selected);
    }
}

static void game_entry(void)
{
    game_hw_init();
    (void)create_thread("GameDisplay", game_display_task, DISPLAY_TASK_STACK_SIZE);
    (void)create_thread("GameKeys", game_key_task, KEY_TASK_STACK_SIZE);
    (void)create_thread("GameCtrl", game_controller_task, GAME_TASK_STACK_SIZE);
}

OHOS_APP_RUN(game_entry);
