#include "game_port.h"

#include <stdbool.h>
#include <string.h>

#define PLANE_PLAYER_Y             7
#define PLANE_PLAYER_NOSE_Y        6
#define PLANE_BULLET_MAX           3
#define PLANE_ENEMY_MAX            3
#define PLANE_SCORE_PER_KILL       10

typedef struct {
    bool active;
    int8_t x;
    int8_t y;
} plane_actor_t;

static uint8_t g_player_x;
static plane_actor_t g_bullets[PLANE_BULLET_MAX];
static plane_actor_t g_enemies[PLANE_ENEMY_MAX];
static uint8_t g_spawn_timer;
static uint16_t g_score;
static bool g_fire_request;

static bool plane_point_in_board(int8_t x, int8_t y)
{
    return (x >= 0) && (x < (int8_t)GAME_BOARD_SIZE) &&
        (y >= 0) && (y < (int8_t)GAME_BOARD_SIZE);
}

static bool plane_player_has_pixel(int8_t x, int8_t y)
{
    if ((y == (int8_t)PLANE_PLAYER_NOSE_Y) && (x == (int8_t)g_player_x)) {
        return true;
    }
    if (y != (int8_t)PLANE_PLAYER_Y) {
        return false;
    }
    return (x == (int8_t)g_player_x) ||
        ((g_player_x > 0U) && (x == (int8_t)(g_player_x - 1U))) ||
        ((g_player_x < (GAME_BOARD_SIZE - 1U)) && (x == (int8_t)(g_player_x + 1U)));
}

static bool plane_enemy_has_pixel(const plane_actor_t *enemy, int8_t x, int8_t y)
{
    if (!enemy->active) {
        return false;
    }
    if ((x == enemy->x) && (y == enemy->y)) {
        return true;
    }
    if (y != (int8_t)(enemy->y + 1)) {
        return false;
    }
    return (x == (int8_t)(enemy->x - 1)) || (x == (int8_t)(enemy->x + 1));
}

static void plane_set_frame_pixel(uint8_t frame[GAME_FRAME_BYTES], int8_t x, int8_t y)
{
    if (plane_point_in_board(x, y)) {
        frame[(uint8_t)y] |= (uint8_t)(1U << (uint8_t)x);
    }
}

static void plane_spawn_enemy(void)
{
    uint8_t index;

    for (index = 0; index < PLANE_ENEMY_MAX; index++) {
        if (!g_enemies[index].active) {
            g_enemies[index].active = true;
            g_enemies[index].x = (int8_t)(1U + (game_rand() % (GAME_BOARD_SIZE - 2U)));
            g_enemies[index].y = 0;
            g_spawn_timer = (uint8_t)(3U + (game_rand() % 3U));
            return;
        }
    }
    g_spawn_timer = 3;
}

static void plane_fire(void)
{
    uint8_t index;

    for (index = 0; index < PLANE_BULLET_MAX; index++) {
        if (!g_bullets[index].active) {
            g_bullets[index].active = true;
            g_bullets[index].x = (int8_t)g_player_x;
            g_bullets[index].y = (int8_t)(PLANE_PLAYER_NOSE_Y - 1U);
            return;
        }
    }
}

static void plane_init(uint16_t score)
{
    (void)memset(g_bullets, 0, sizeof(g_bullets));
    (void)memset(g_enemies, 0, sizeof(g_enemies));
    g_player_x = 3;
    g_spawn_timer = 2;
    g_score = score;
    g_fire_request = false;
}

static void plane_handle_key(game_key_t key)
{
    switch (key) {
        case GAME_KEY_LEFT:
            if (g_player_x > 1U) {
                g_player_x--;
            }
            break;
        case GAME_KEY_RIGHT:
            if (g_player_x < (GAME_BOARD_SIZE - 2U)) {
                g_player_x++;
            }
            break;
        case GAME_KEY_FUNC:
            plane_fire();
            g_fire_request = false;
            break;
        default:
            return;
    }
    game_wake_controller(GAME_EVENT_KEY);
}

static bool plane_handle_bullet_hits(void)
{
    uint8_t b;
    uint8_t e;

    for (b = 0; b < PLANE_BULLET_MAX; b++) {
        if (!g_bullets[b].active) {
            continue;
        }
        for (e = 0; e < PLANE_ENEMY_MAX; e++) {
            if (plane_enemy_has_pixel(&g_enemies[e], g_bullets[b].x, g_bullets[b].y)) {
                g_bullets[b].active = false;
                g_enemies[e].active = false;
                g_score = (uint16_t)(g_score + PLANE_SCORE_PER_KILL);
                game_buzzer_beep(55);
                break;
            }
        }
    }
    return true;
}

static bool plane_player_collided(void)
{
    uint8_t e;
    int8_t x;
    int8_t y;

    for (e = 0; e < PLANE_ENEMY_MAX; e++) {
        if (!g_enemies[e].active) {
            continue;
        }
        for (y = (int8_t)PLANE_PLAYER_NOSE_Y; y <= (int8_t)PLANE_PLAYER_Y; y++) {
            for (x = (int8_t)(g_player_x - 1U); x <= (int8_t)(g_player_x + 1U); x++) {
                if (plane_player_has_pixel(x, y) && plane_enemy_has_pixel(&g_enemies[e], x, y)) {
                    return true;
                }
            }
        }
    }
    return false;
}

static bool plane_step(void)
{
    uint8_t index;

    if (g_fire_request) {
        plane_fire();
    }
    g_fire_request = false;

    for (index = 0; index < PLANE_BULLET_MAX; index++) {
        if (g_bullets[index].active) {
            g_bullets[index].y--;
            if (g_bullets[index].y < 0) {
                g_bullets[index].active = false;
            }
        }
    }
    (void)plane_handle_bullet_hits();

    for (index = 0; index < PLANE_ENEMY_MAX; index++) {
        if (g_enemies[index].active) {
            g_enemies[index].y++;
            if (g_enemies[index].y >= (int8_t)GAME_BOARD_SIZE) {
                g_enemies[index].active = false;
            }
        }
    }
    (void)plane_handle_bullet_hits();

    if (plane_player_collided()) {
        return false;
    }

    if (g_spawn_timer > 0U) {
        g_spawn_timer--;
    }
    if (g_spawn_timer == 0U) {
        plane_spawn_enemy();
    }
    return true;
}

static void plane_render(uint8_t frame[GAME_FRAME_BYTES])
{
    uint8_t index;

    (void)memset(frame, 0, GAME_FRAME_BYTES);
    plane_set_frame_pixel(frame, (int8_t)g_player_x, (int8_t)PLANE_PLAYER_NOSE_Y);
    plane_set_frame_pixel(frame, (int8_t)(g_player_x - 1U), (int8_t)PLANE_PLAYER_Y);
    plane_set_frame_pixel(frame, (int8_t)g_player_x, (int8_t)PLANE_PLAYER_Y);
    plane_set_frame_pixel(frame, (int8_t)(g_player_x + 1U), (int8_t)PLANE_PLAYER_Y);

    for (index = 0; index < PLANE_BULLET_MAX; index++) {
        if (g_bullets[index].active) {
            plane_set_frame_pixel(frame, g_bullets[index].x, g_bullets[index].y);
        }
    }

    for (index = 0; index < PLANE_ENEMY_MAX; index++) {
        if (g_enemies[index].active) {
            plane_set_frame_pixel(frame, g_enemies[index].x, g_enemies[index].y);
            plane_set_frame_pixel(frame, (int8_t)(g_enemies[index].x - 1), (int8_t)(g_enemies[index].y + 1));
            plane_set_frame_pixel(frame, (int8_t)(g_enemies[index].x + 1), (int8_t)(g_enemies[index].y + 1));
        }
    }
}

static uint16_t plane_score(void)
{
    return g_score;
}

static void plane_revive(void)
{
    (void)memset(g_bullets, 0, sizeof(g_bullets));
    (void)memset(g_enemies, 0, sizeof(g_enemies));
    g_player_x = 3;
    g_spawn_timer = 3;
    g_fire_request = false;
}

const game_driver_t g_plane_driver = {
    .id = GAME_ID_PLANE,
    .name = "plane",
    .tick_ms = 320,
    .init = plane_init,
    .handle_key = plane_handle_key,
    .step = plane_step,
    .render = plane_render,
    .score = plane_score,
    .revive = plane_revive
};
